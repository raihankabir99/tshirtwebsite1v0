import type { Metadata } from 'next'
import { Header } from '@/components/site/header'
import { Footer } from '@/components/site/footer'
import { PageHeader } from '@/components/site/page-header'
import { ProductGrid } from '@/components/commerce/product-grid'
import { ALL_PRODUCTS } from '@/lib/data'

export const metadata: Metadata = {
  title: 'Shop',
  description:
    'Shop original designs across apparel, accessories and lifestyle goods — produced on demand and shipped worldwide.',
}

export default function ShopPage() {
  return (
    <>
      <Header />
      <main id="main">
        <PageHeader
          eyebrow="Shop"
          title="The full range"
          description="Original designs across apparel, accessories and lifestyle goods — printed to order."
          crumbs={[{ label: 'Home', href: '/' }, { label: 'Shop' }]}
        />
        <ProductGrid products={ALL_PRODUCTS} />
      </main>
      <Footer />
    </>
  )
}
