import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { Header } from '@/components/site/header'
import { Footer } from '@/components/site/footer'
import { PageHeader } from '@/components/site/page-header'
import { ProductGrid } from '@/components/commerce/product-grid'
import { ProductRail } from '@/components/home/product-rail'
import {
  ALL_PRODUCTS,
  PRODUCT_TYPES,
  productTypeBySlug,
  BEST_SELLERS,
} from '@/lib/data'

export function generateStaticParams() {
  return PRODUCT_TYPES.map((t) => ({ type: t.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ type: string }>
}): Promise<Metadata> {
  const { type } = await params
  const pt = productTypeBySlug(type)
  return {
    title: pt ? pt.name : 'Shop',
    description: pt
      ? `Shop ${pt.name} — original designs printed on demand and shipped worldwide.`
      : undefined,
  }
}

export default async function ShopTypePage({
  params,
}: {
  params: Promise<{ type: string }>
}) {
  const { type } = await params
  const pt = productTypeBySlug(type)
  if (!pt) notFound()

  const products = ALL_PRODUCTS.filter(
    (p) => p.productType === pt.name || p.productType + 's' === pt.name,
  )

  return (
    <>
      <Header />
      <main id="main">
        <PageHeader
          eyebrow={pt.group}
          title={pt.name}
          description={`Original designs on ${pt.name.toLowerCase()}, printed to order on premium blanks.`}
          crumbs={[
            { label: 'Home', href: '/' },
            { label: 'Shop', href: '/shop' },
            { label: pt.name },
          ]}
        />
        {products.length > 0 ? (
          <ProductGrid products={products} />
        ) : (
          <ProductRail
            eyebrow="Coming soon"
            title={`${pt.name} — in the studio`}
            description={`We're preparing this design on ${pt.name.toLowerCase()}. In the meantime, explore our best sellers.`}
            cta={{ label: 'All products', href: '/products' }}
            products={BEST_SELLERS}
          />
        )}
      </main>
      <Footer />
    </>
  )
}
