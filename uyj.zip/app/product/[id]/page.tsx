import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { Header } from '@/components/site/header'
import { Footer } from '@/components/site/footer'
import { ProductDetail } from '@/components/commerce/product-detail'
import { ProductRail } from '@/components/home/product-rail'
import { ALL_PRODUCTS, getProductById } from '@/lib/data'

export function generateStaticParams() {
  return ALL_PRODUCTS.map((p) => ({ id: p.id }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>
}): Promise<Metadata> {
  const { id } = await params
  const product = getProductById(id)
  return {
    title: product ? product.title : 'Product',
    description: product
      ? `${product.designName} on a ${product.productType}. Original design, made on demand.`
      : undefined,
  }
}

export default async function ProductPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const product = getProductById(id)
  if (!product) notFound()

  const related = ALL_PRODUCTS.filter(
    (p) => p.id !== product.id && p.designSlug !== product.designSlug,
  ).slice(0, 4)

  return (
    <>
      <Header />
      <main id="main">
        <ProductDetail product={product} />
        {related.length > 0 && (
          <ProductRail
            eyebrow="You may also like"
            title="More from the studio"
            cta={{ label: 'All products', href: '/products' }}
            products={related}
          />
        )}
      </main>
      <Footer />
    </>
  )
}
