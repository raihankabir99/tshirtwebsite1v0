import type { Metadata } from 'next'
import { Header } from '@/components/site/header'
import { Footer } from '@/components/site/footer'
import { PageHeader } from '@/components/site/page-header'
import { ProductGrid } from '@/components/commerce/product-grid'
import { ALL_PRODUCTS } from '@/lib/data'

export const metadata: Metadata = {
  title: 'All Products',
  description:
    'The full catalog — original designs across apparel, accessories and lifestyle goods, made on demand.',
}

export default function ProductsPage() {
  return (
    <>
      <Header />
      <main id="main">
        <PageHeader
          eyebrow="Shop"
          title="All products"
          description="Every design, across every product. Filter by type or sort to find your piece."
          crumbs={[{ label: 'Home', href: '/' }, { label: 'All Products' }]}
        />
        <ProductGrid products={ALL_PRODUCTS} />
      </main>
      <Footer />
    </>
  )
}
