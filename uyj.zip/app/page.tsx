import { Header } from '@/components/site/header'
import { Footer } from '@/components/site/footer'
import { Hero } from '@/components/home/hero'
import { ProductRail } from '@/components/home/product-rail'
import { OneDesign } from '@/components/home/one-design'
import { TrendingDesigns } from '@/components/home/trending-designs'
import { FeaturedCategories } from '@/components/home/featured-categories'
import { EditorialBand } from '@/components/home/editorial-band'
import { HowItWorks } from '@/components/home/how-it-works'
import { Journal } from '@/components/home/journal'
import { Reviews } from '@/components/home/reviews'
import { Newsletter } from '@/components/site/newsletter'
import { NEW_DROPS, BEST_SELLERS } from '@/lib/data'

export default function HomePage() {
  return (
    <>
      <Header overlay />
      <main id="main">
        <Hero />

        <ProductRail
          eyebrow="Just landed"
          title="New drops"
          description="The latest designs from the studio, ready to wear across every product."
          cta={{ label: 'Shop new drops', href: '/new-drops' }}
          products={NEW_DROPS}
        />

        <OneDesign />

        <TrendingDesigns />

        <FeaturedCategories />

        <EditorialBand />

        <ProductRail
          eyebrow="Most loved"
          title="Best sellers"
          description="The pieces our community keeps coming back to."
          cta={{ label: 'Shop best sellers', href: '/best-sellers' }}
          products={BEST_SELLERS}
        />

        <HowItWorks />

        <Reviews />

        <Journal />

        <Newsletter />
      </main>
      <Footer />
    </>
  )
}
