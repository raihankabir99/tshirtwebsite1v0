import type { Metadata } from 'next'
import { Header } from '@/components/site/header'
import { Footer } from '@/components/site/footer'
import { PageHeader } from '@/components/site/page-header'
import { ProductGrid } from '@/components/commerce/product-grid'
import { NEW_DROPS, BEST_SELLERS } from '@/lib/data'

export const metadata: Metadata = {
  title: 'New Drops',
  description: 'The latest designs from the studio — just landed and ready to wear.',
}

export default function NewDropsPage() {
  return (
    <>
      <Header />
      <main id="main">
        <PageHeader
          eyebrow="Just landed"
          title="New drops"
          description="The latest artwork from the studio, released in small considered batches."
          crumbs={[{ label: 'Home', href: '/' }, { label: 'New Drops' }]}
        />
        <ProductGrid products={[...NEW_DROPS, ...BEST_SELLERS]} />
      </main>
      <Footer />
    </>
  )
}
